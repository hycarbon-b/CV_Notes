# include <stdio.h>
# include <stdlib.h>
# include <assert.h>
# include "set.h"

set newset(){
	set myset = malloc(sizeof(set));
	assert(myset != NULL);
	myset->start = NULL;
	return myset;
};
void insert_set(set* s, int v){
	node* now = (*s)->start;    // now is a pointer 
	while(v >= now->value){
		if(now == NULL){
			(*set)->start = 
		}
		now = now->next;
	}
	node *newnode = malloc(sizeof(node));
	newnode->value = v;
	now->next = newnode;
}
void search_set(set* s, int v){
	node* current = (*s)->start;
	while (current != NULL) {
		if (current->value == v) {
			printf("Value %d found in the set.\n", v);
			return;
		}
		current = current->next;
	}
	printf("Value %d not found in the set.\n", v);
}

void del_set(set* s, int v){
	node* current = (*s)->start;
	node* prev = NULL;
	while (current != NULL) {
		if (current->value == v) {
			if (prev == NULL) {
				(*s)->start = current->next;
			} else {
				prev->next = current->next;
			}
			free(current);
			printf("Value %d deleted from the set.\n", v);
			return;
		}
		prev = current;
		current = current->next;
	}
	printf("Value %d not found in the set.\n", v);
}

void print_set(set* s){
	node* current = (*s)->start;
	printf("Set: ");
	while (current != NULL) {
		printf("%d ", current->value);
		current = current->next;
	}
	printf("\n");
}

void destruction(set* s){
	node* current = (*s)->start;
	while (current != NULL) {
		node* temp = current;
		current = current->next;
		free(temp);
	}
	free(*s);
	*s = NULL;
}
int main(){
	set myset = newset();
	printf("%p", myset->start->next);
//	insert_set(&myset, 1);
//	insert_set(&myset, 2);
//	printf("%d",(myset->start)->value);
	return 0;
}

