#ifndef SET
#define SET
#define MAX 1000

typedef enum boolean {false, true} boolean; 

typedef struct node {
	struct node* next;
	struct node* prev;
	int value;
}node;
struct set{
	node* start;
};
typedef struct set* set;
set newset();
boolean empty(set*);
void insert_set(set*, int v);
void search_set(set*, int v);
void del_set(set*, int v);
void print_set(set*, int v);
void destruction(set*);

#endif
